import React from 'react'

const Mens = () => {
  return (
    <div>
      
    </div>
  )
}

export default Mens
