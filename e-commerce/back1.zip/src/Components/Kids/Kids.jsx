import React from 'react'

const Kids = () => {
  return (
    <div>
    </div>
  )
}

export default Kids
