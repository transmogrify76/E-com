import React from 'react'

const Women = () => {
  return (
    <div>
      
    </div>
  )
}

export default Women
