import React from 'react'
import CartItems from '../CartItems/CartItems'

const Cart = () => {
  return (
    <div className='cartitems'>
   <CartItems/>
    </div>
      
  )
}

export default Cart
